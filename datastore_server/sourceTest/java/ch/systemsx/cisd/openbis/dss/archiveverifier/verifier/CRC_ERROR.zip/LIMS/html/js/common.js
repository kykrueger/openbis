// Features Missing
// 1. Search
// 2. Show Parent / Children when the user chicks on the inspector code
// 3. Show XML properties as table with parser

//
// Configuration
//

var openbisUrl = 'https://openbis-lims.ethz.ch/';
var dssUrl = 'https://openbis-lims.ethz.ch/datastore_server';
// var openbisUrl = 'https://localhost:8443/';
// var dssUrl = 'https://localhost:8444/datastore_server';

var ALL_SAMPLE_TYPES = {
	"BACTERIA" : {
		"DISPLAY_NAME" : "Bacteria",
		"SAMPLE_TYPE_PROPERTIES" : ["BACTERIA_STRAIN_NAME", "BACTERIA_GENOTYPE", "WHAT_FOR", "SUPPLIER", "ARTICLE_NUMBER", "COMMENTS"],
		"SAMPLE_TYPE_PROPERTIES_DISPLAY_NAME" : ["Bacteria Strain Name", "Bacteria Genotype", "For What", "Supplier", "Art. Number", "Comments"],
		"INSPECTOR_ORDER" : {"FOR_WHAT" : "null", "SUPPLIER" : "null", "DATA_SETS" : "null", "COMMENTS" : "null", "BOX_NUMBER" : "null", "ROW" : "null", "COLUMN" : "null"}
	},
	"CHEMICAL" : {
		"DISPLAY_NAME" : "Chemical",
		"SAMPLE_TYPE_PROPERTIES" : ["NAME", "SUPPLIER", "ARTICLE_NUMBER", "LOCAL_ID", "STORAGE"],
		"SAMPLE_TYPE_PROPERTIES_DISPLAY_NAME" : ["Name", "Supplier", "Art. Number", "Local ID", "Storage"],
		"INSPECTOR_ORDER" : {"NAME" : "null", "SUPPLIER" : "null", "ARTICLE_NUMBER" : "null", "LOCAL_ID" : "null", "STORAGE" : "null" }
	},
	"ANTIBODY" : {
		"DISPLAY_NAME" : "Antibody",
		"SAMPLE_TYPE_PROPERTIES" : ["NAME", "STORAGE", "HOST", "FOR_WHAT"],
		"SAMPLE_TYPE_PROPERTIES_DISPLAY_NAME" : ["Name", "Storage", "Host", "For What"],
		"INSPECTOR_ORDER" : {"NAME" : "null", "FOR_WHAT" : "null", "SUPPLIER" : "null", "ARTICLE_NUMBER" : "null", "STORAGE" : "null", "STOCK_CONCENTRATION" : "null", "DATA_SETS" : "null", "EPITOPE" : "null", "CLONALITY" : "null", "ISOTYPE" : "null"}
	},
	"MEDIA" : {
		"DISPLAY_NAME" : "Media",
		"SAMPLE_TYPE_PROPERTIES" : ["NAME", "STORAGE", "FOR_WHAT", "ORGANISM"],
		"SAMPLE_TYPE_PROPERTIES_DISPLAY_NAME" : ["Name", "Storage", "For What", "Organism"],
		"INSPECTOR_ORDER" : {"NAME" : "null", "FOR_WHAT" : "null", "STORAGE" : "null", "STOCK_CONCENTRATION" : "null", "STERILIZATION" : "null", "DETAILS" : "null", "CHEMICALS" : "null", "MEDIA" : "null", "XMLCOMMENTS" : "null" }
	},
	"SOLUTIONS_BUFFERS" : {
		"DISPLAY_NAME" : "Solutions Buffers",
		"SAMPLE_TYPE_PROPERTIES" : ["NAME", "STORAGE", "FOR_WHAT"],
		"SAMPLE_TYPE_PROPERTIES_DISPLAY_NAME" : ["Name", "Storage", "For What"],
		"INSPECTOR_ORDER" : {"NAME" : "null", "FOR_WHAT" : "null", "STORAGE" : "null", "STOCK_CONCENTRATION" : "null", "STERILIZATION" : "null", "DETAILS" : "null", "CHEMICALS" : "null", "MEDIA" : "null", "XMLCOMMENTS" : "null" }
	},
	"ENZYME" : {
		"DISPLAY_NAME" : "Enzyme",
		"SAMPLE_TYPE_PROPERTIES" : ["NAME", "SUPPLIER", "ARTICLE_NUMBER", "KIT"],
		"SAMPLE_TYPE_PROPERTIES_DISPLAY_NAME" : ["Name", "Supplier", "Art. Number", "Kit Including"],
		"INSPECTOR_ORDER" : {"NAME" : "null", "SUPPLIER" : "null", "ARTICLE_NUMBER" : "null", "STORAGE" : "null", "KIT" : "null", "DATA_SETS" : "null" }
	},
	"OLIGO" : {
		"DISPLAY_NAME" : "Oligo",
		"SAMPLE_TYPE_PROPERTIES" : ["TARGET", "DIRECTION", "RESTRICTION_ENZYME", "PROJECT"],
		"SAMPLE_TYPE_PROPERTIES_DISPLAY_NAME" : ["Target", "Direction", "Restriction Enzyme", "Project"],
		"INSPECTOR_ORDER" : {"TARGET" : "null", "DIRECTION" : "null", "RESTRICTION_ENZYME" : "null", "SEQUENCE" : "null", "PROJECT" : "null", "BOX_NUMBER" : "null", "ROW" : "null", "COLUMN" : "null" }
	},
	"PLASMID" : {
		"DISPLAY_NAME" : "Plasmid",
		"SAMPLE_TYPE_PROPERTIES" : ["OWNER", "OWNER_NUMBER", "PLASMID_NAME", "BACKBONE", "BACTERIAL_ANTIBIOTIC_RESISTANCE", "YEAST_MARKER"],
		"SAMPLE_TYPE_PROPERTIES_DISPLAY_NAME" : ["Owner", "Owner Number", "Plasmid Name", "Backbone", "Bacterial Antibiotic Resistance", "(Yeast) Marker"],
		"INSPECTOR_ORDER" : {"OWNER" : "null", "COMMENTS" : "null", "PLASMID_NAME" : "null", "BACKBONE" : "null", "BACTERIAL_ANTIBIOTIC_RESISTANCE" : "null", "DATA_SETS" : "null", "BOX_NUMBER" : "null", "ROW" : "null", "COLUMN" : "null" }
	},
	"YEAST" : {
		"DISPLAY_NAME" : "Yeast",
		"SAMPLE_TYPE_PROPERTIES" : ["OWNER", "OWNER_NUMBER", "YEAST_STRAIN_NAME", "PROJECT", "PLASMIDS_PARENTS", "YEASTS_PARENTS", "GENETIC_BACKGROUND", "MATING_TYPE"],
		"SAMPLE_TYPE_PROPERTIES_DISPLAY_NAME" : ["Owner", "Owner Number", "Yeast Strain Name", "Project", "Plasmids", "Yeast Parents", "Genetic Background", "Mating Type"],
		"INSPECTOR_ORDER" : {"OWNER" : "null", "YEAST_STRAIN_NAME" : "null", "PLASMIDS_PARENTS" : "null", "GENETIC_BACKGROUND" : "null", "MATING_TYPE" : "null", "COMMON_MARKERS" : "null", "SOURCE" : "null", "BOX_NUMBER" : "null" ,"ROW" : "null", "COLUMN" : "null" }
	},
	"GENERAL_PROTOCOL" : {
		"DISPLAY_NAME" : "Protocols",
		"SAMPLE_TYPE_PROPERTIES" : ["NAME", "WHAT_FOR", "PROTOCOL_TYPE", "PUBLICATION"],
		"SAMPLE_TYPE_PROPERTIES_DISPLAY_NAME" : ["Name", "For What", "Protocol Type", "Publication"],
		"INSPECTOR_ORDER" : {"NAME" : "null", "FOR_WHAT" : "null", "MATERIALS" : "null", "PROCEDURE" : "null", "PROTOCOL_EVALUATION" : "null", "CHEMICALS" : "null", "MEDIA" : "null", "SOLUTIONS_BUFFERS" : "null" ,"GENERAL_PROTOCOL" : "null", "XMLCOMMENTS" : "null", "SUGGESTIONS" : "null" }
	},
	"PCR" : {
		"DISPLAY_NAME" : "PCR",
		"SAMPLE_TYPE_PROPERTIES" : ["NAME", "WHAT_FOR", "TEMPLATE", "PUBLICATION"],
		"SAMPLE_TYPE_PROPERTIES_DISPLAY_NAME" : ["Name", "For What", "Template", "Publication"],
		"INSPECTOR_ORDER" : {"NAME" : "null", "FOR_WHAT" : "null", "CHEMICALS" : "null", "MEDIA" : "null", "TEMPLATE" : "null", "THERMOCYCLER_PROTOCOL" : "null", "REACTION_MIX" : "null", "PROTOCOL_EVALUATION" : "null", "PLASMIDS_PARENTS" : "null", "SOLUTIONS_BUFFERS" : "null", "XMLCOMMENTS" : "null", "SUGGESTIONS" : "null" }
	},
	"WESTERN_BLOTTING" : {
		"DISPLAY_NAME" : "Western Blotting",
		"SAMPLE_TYPE_PROPERTIES" : ["NAME", "WHAT_FOR", "STORAGE", "PUBLICATION"],
		"SAMPLE_TYPE_PROPERTIES_DISPLAY_NAME" : ["Name", "For What", "Storage", "Publication"],
		"INSPECTOR_ORDER" : {"NAME" : "null", "FOR_WHAT" : "null", "STORAGE" : "null", "DATA_SETS" : "null", "COMMENTS" : "null", "CHEMICALS" : "null", "SOLUTIONS_BUFFERS" : "null", "MEMBRANE" : "null", "ANTIBODY_DILUTION" : "null", "ANTIBODY_SOLUTION" : "null", "XMLCOMMENTS" : "null"}
	}
	/**,
	"TEMPLATE_SAMPLE" : {
		"DISPLAY_NAME" : "Template",
		"SAMPLE_TYPE_PROPERTIES" : ["TEMPLATE_DESCRIPTION", "TEMPLATE_NUMBER", "TEMPLATE_TEXT"],
		"SAMPLE_TYPE_PROPERTIES_DISPLAY_NAME" : ["Description", "Number", "Text"]
	}**/
}

//
// Unknown
//

function dataset(sample, data) {
   if(data.result){
      for (var i = 0; i < data.result.length; i++) {
        console.log(data.result)
        openbisServer.listFilesForDataSet(data.result[i].code, "/", true, filelist.curry(sample, data.result[i]));
      }
   }
}

function filelist(sample, dataset, files) {
	for (var i in files.result) {
		if (!files.result[i].isDirectory) {
			var inspector = inspectors.select("#"+sample.code+"_INSPECTOR");
			var pathInDataSet = files.result[i].pathInDataSet;
			
			if(pathInDataSet){
				var downloadUrl = dssUrl+"/"+dataset.code+"/"+pathInDataSet+"?sessionID=" + openbisServer.getSession();
				inspector.select("td.data_sets").append("a").attr("href", downloadUrl).text(pathInDataSet)
				inspector.select("td.data_sets").append("br");
				
				if (/\.svg$/.test(pathInDataSet)) {
						// Retrieve the svg file and inject it into the DOM
						d3.xml(downloadUrl, "image/svg+xml", function(xml) {
							var importedNode = document.importNode(xml.documentElement, true);
							d3.select(importedNode)
								.attr("width", inspectorsWidth - 20)
								.attr("height", inspectorsWidth - 20)
								.attr("viewBox", "200 200 650 650");
							inspector.node().appendChild(importedNode);
						});
				}
			}
		}
	}
}

//
// Main Table
//

function createTableFromProperties() {
	var tableTemplate = "<table style='width:100%;' class='table table-hover' id=\"yeast-table\"><thead>";
	
	tableTemplate += "<tr style='border:none; border-collapse:collapse;'><td></td>";
	for(var i=0; i<SAMPLE_TYPE_PROPERTIES_DISPLAY_NAME.length;i++) {
		tableTemplate += "<td style='border:none; border-collapse:collapse;'><input placeholder='"+SAMPLE_TYPE_PROPERTIES_DISPLAY_NAME[i]+" filter' style=\"width: 100%\" id=\""+SAMPLE_TYPE_PROPERTIES[i]+"_filter\" type=\"text\"></td>";
	}
	tableTemplate += "</tr>";
	
	tableTemplate += "<tr class=\"yeast-table-header\"><th>Code</th>";
	for(var i=0; i<SAMPLE_TYPE_PROPERTIES_DISPLAY_NAME.length;i++) {
		tableTemplate += "<th>" + SAMPLE_TYPE_PROPERTIES_DISPLAY_NAME[i]+ "</th>";
	}
	tableTemplate += "<th></th></tr></thead><tbody id='sample-data-holder'></tbody></table>";
	
	$("#tableContainer").empty();
	$("#tableContainer").append(tableTemplate);
	
	for(var i=0;i<SAMPLE_TYPE_PROPERTIES.length;i++) {
		$('#'+SAMPLE_TYPE_PROPERTIES[i]+'_filter').keyup(function() {
			var filterResults = [];
			for(var i=0;i<SAMPLE_TYPE_PROPERTIES.length;i++) {
				filterResults[i] = $('#'+SAMPLE_TYPE_PROPERTIES[i]+'_filter').val();
			}
			
			visualize(
				filterResults
			);
		});	
	}
}

/**
 * Menu
 */
function reload(typeToReload) {
	if(typeToReload != null) {
		SAMPLE_TYPE = typeToReload;
		SAMPLE_TYPE_PROPERTIES = ALL_SAMPLE_TYPES[SAMPLE_TYPE]["SAMPLE_TYPE_PROPERTIES"];
		SAMPLE_TYPE_PROPERTIES_DISPLAY_NAME = ALL_SAMPLE_TYPES[SAMPLE_TYPE]["SAMPLE_TYPE_PROPERTIES_DISPLAY_NAME"];
	}
	$("#tableMessages").empty();
	$("#sectionsContainer").empty();
	$("#tableContainer").empty();
	
	populateMenu(SAMPLE_TYPE);
	createTableFromProperties();
	showMatchingSamples();
}

function populateMenu(activeId) {
	
	var menuInner = "";
		menuInner += "<ul class='nav'>";
		for(sampleType in ALL_SAMPLE_TYPES) {
			menuInner += "<li id='"+sampleType+"'><a onclick='jsfunction' href='javascript:reload(\""+sampleType+"\");'>"+ALL_SAMPLE_TYPES[sampleType]["DISPLAY_NAME"]+"</a></li>";
		}
		//menuInner += "<li id='search_browser'><a href='search-browser.html'>Search</a></li>";
		menuInner += "</ul>";
		
	var menu = "";
		menu += "<div class='navbar-wrapper'>";
		menu += "<div class='navbar'>";
		menu += "<div class='navbar-inner'>";
		
		menu += "<div class='nav-collapse collapse'>";
		menu += menuInner;
		menu += "</div> <!--/.nav-collapse -->"; 
		
		menu += "<div class='pull-right'>";
		menu += "<button class='btn' id='logout-button'>Logout</button>";
		menu += "</div>";
		
		menu += "<button type='button' class='btn btn-navbar pull-left' data-toggle='collapse' data-target='.nav-collapse'>";
		menu += "<span class='icon-bar'></span>";
		menu += "<span class='icon-bar'></span>";
		menu += "<span class='icon-bar'></span>";
		menu += "</button>";
		
		menu += "</div> <!-- /.navbar-inner -->";
		menu += "</div> <!-- /.navbar -->";
		menu += "</div> <!-- /.navbar-wrapper -->";
		
	$("#sectionsContainer").empty();
	$("#sectionsContainer").append(menu);
	
	$('#logout-button').click(function() { 
		openbisServer.logout(function(data) { 
			$("#login-form-div").show();
			$("#main").hide();
			$("#username").focus();
		});
	});
	
	$('#'+activeId).addClass('active');
}

/**
 * Edit button Event
 */
function showEditWindowForSample(code, permId) {
	//Working Example: https://sprint-openbis.ethz.ch/openbis/?viewMode=embedded#action=EDITING&entity=SAMPLE&code=A123&permId=20091006093948112-162773
	var editURLTemplate = openbisUrl + "openbis/?viewMode=embedded#action=EDITING&entity=SAMPLE";
	var codeParam = "&code="+code;
	var permId = "&permId="+permId;
	var sessionId = "&sessionID="+openbisServer.getSession();
	window.open(editURLTemplate+codeParam+permId+sessionId,null,null);
}

/**
 * Inspectors Related
 */
function updateInspectors(currentSamples)
{	
	var inspectors = "";
	for(var i=0;i<currentSamples.length;i++) {
		inspectors += getInspectorTable(currentSamples[i], i);
	}
	$("#inspectorsContainer").empty();
	$("#inspectorsContainer").append(inspectors);
}

function getInspectorTable(entity, index) {
	
	var inspector = "";
		inspector += "<div id='"+entity.code+"_INSPECTOR' class='inspector'>";
		inspector += entity.code;
		inspector += "<span class='close' onclick='closeNewInspector("+index+")'>x</span>";
		inspector += "<table class='properties table'>"
		
		//Show Properties following an order if is given
		var INSPECTOR_ORDER = ALL_SAMPLE_TYPES[entity.sampleTypeCode]["INSPECTOR_ORDER"];
		if(INSPECTOR_ORDER == null) {
			INSPECTOR_ORDER = entity.properties;
		}
		
		for(property in INSPECTOR_ORDER) {
			// To not to show empty stuff
			//if ((entity.properties[property] instanceof Array) && entity.properties[property].length == 0) {
			//	continue;
			//}
			
			inspector += "<tr>";
			inspector += "<td class='property'>"+property+"</td>";
			var propertyContent = entity.properties[property];
			
			if(	property === "CHEMICALS" || 
				property === "CHEMICALS" ||
				property === "SOLUTIONS_BUFFERS") {
				//TO-DO Parse XML following a standard manner
			}
			
			if((propertyContent instanceof String) || (typeof propertyContent === "string")) {
				propertyContent = propertyContent.replace(/\n/g, "<br />");
			}
			
			inspector += "<td class='property'>"+propertyContent+"</td>";
			inspector += "</tr>";
		}
		
		//Properties not found on the ordered list, with this new properties appear directly
		if(ALL_SAMPLE_TYPES[entity.sampleTypeCode]["INSPECTOR_ORDER"]) {
			for(property in entity.properties) {
				if(ALL_SAMPLE_TYPES[entity.sampleTypeCode]["INSPECTOR_ORDER"][property]) {
					continue; //Skip the ones already printed
				}
				// To not to show empty stuff
				//if ((entity.properties[property] instanceof Array) && entity.properties[property].length == 0) {
				//	continue;
				//}
			
				inspector += "<tr>";
				inspector += "<td class='property'>"+property+"</td>";
				var propertyContent = entity.properties[property];
			
				if(	property === "CHEMICALS" || 
					property === "CHEMICALS" ||
					property === "SOLUTIONS_BUFFERS") {
					//TO-DO Parse XML following a standard manner
				}
			
				if((propertyContent instanceof String) || (typeof propertyContent === "string")) {
					propertyContent = propertyContent.replace(/\n/g, "<br />");
				}
			
				inspector += "<td class='property'>"+propertyContent+"</td>";
				inspector += "</tr>";
			}
		}
		
		//Show Parent Codes
		for(var i = 0; i < entity.parents.length; i++) {
			var parent = entity.parents[i];
			inspector += "<tr>";
			inspector += "<td class='property'>PARENT "+(i+1)+"</td>";
			inspector += "<td class='property'>"+parent.code+"</td>";
			inspector += "</tr>";
		}
		
		//Show Children Codes
		for(var i = 0; i < entity.children.length; i++) {
			var child = entity.children[i];
			inspector += "<tr>";
			inspector += "<td class='property'>CHILD "+(i+1)+"</td>";
			inspector += "<td class='property'>"+child.code+"</td>";
			inspector += "</tr>";
		}
		
		//Show Modification Date
		inspector += "<tr>";
		inspector += "<td class='property'>Modification Date</td>";
		inspector += "<td class='property'>"+new Date(entity.registrationDetails["modificationDate"])+"</td>";
		inspector += "</tr>";
		
		//Show Creation Date
		inspector += "<tr>";
		inspector += "<td class='property'>Registration Date</td>";
		inspector += "<td class='property'>"+new Date(entity.registrationDetails["registrationDate"])+"</td>";
		inspector += "</tr>";
		
		inspector += "</table>"
		inspector += "</div>"
		
	return inspector;
}

function closeNewInspector(index)
{
	inspectedYeasts.splice(index, 1);
	updateInspectors(inspectedYeasts);
}

__author__ = 'Swen Vermeul'
__email__ = 'swen@ethz.ch'
__version__ = '1.6.7'

from . import pybis
from .pybis import Openbis
from .pybis import DataSet

java -jar microscopy-migration-tool.jar http://localhost:8080 http://localhost:8081 migration 1234 >> microscopy-migration.log 2>&1 &

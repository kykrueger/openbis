// Query dictionary
var query = {


	//
	// Module
	//
	
	query: "Query",
	sql_query: "SQL Query",
	
	query_module_menu_title: "Queries",
	
	query_database_menu_title: "Queries",
	query_execute: "Execute",
	
	RUN_CUSTOM_QUERY_menu_item: "Run Custom SQL Query",
	RUN_CUSTOM_QUERY_tab_label: "Custom SQL Query",
	RUN_CANNED_QUERY_menu_item: "Run Predefined Query",
	RUN_CANNED_QUERY_tab_label: "Predefined Query",

  //
  // Query Browser and Editing
  //
  	
	QUERY_BROWSER_menu_item: "Browse Query Definitions",
	QUERY_BROWSER_tab_label: "Query Definitions",

	button_add_query: "Add Query Definition",
	button_test_query: "Test Query Definition",
	query_deletion_confirmation: "Do you really want to delete the query definitions {0}?",
  query_create_title: "Create Query Definition",
  query_edit_title: "Edit Query Definition",
  query_parameters_binding_dialog_title: "Enter Query Parameters",
  query_type: "Query Type",
  query_database: "Database",
  
    	    	
  // LAST LINE: KEEP IT AT THE END
  lastline: "" // we need a line without a comma
};
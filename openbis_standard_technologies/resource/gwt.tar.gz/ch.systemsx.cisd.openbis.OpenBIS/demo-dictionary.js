// Demo dictionary
var demo = {

	//
	// Module
	//
	
	STATISTICS: "Statistics",
		
	module_menu_title: "Demo",
	statistics_tab_header: "Statistics",

  // LAST LINE: KEEP IT AT THE END
  lastline: "" // we need a line without a comma
};